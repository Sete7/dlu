//---------------------------------------SCRIPT MOBILE------------------------------------------------------
$(document).ready(function () {
    $(".sidebarBtn").click(function () {
        $(".sidebar").toggleClass('active');
        $(".sidebarBtn").toggleClass('toggle');
    });
});